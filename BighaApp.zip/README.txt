1) github.com par naya repository banayein aur is folder ki saari files upload karein (.github folder samet).
2) Repository > Actions > "Build APK" chalne dein (2-3 minute).
3) Run khulne par neeche Artifacts me "bigha-calculator-apk" download karein, zip kholkar app-debug.apk phone me install karein.
